 <div id="Banner" class="banner">
    <div class="banner-wrap">
      <div class="notice-text">We&#x27;re open and available for takeaway &amp; delivery. <a href="order.php" class="white-link">Order Now</a>
      </div>
    </div>
  </div>