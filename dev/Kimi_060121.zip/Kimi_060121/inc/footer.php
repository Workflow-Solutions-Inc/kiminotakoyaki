<div class="section-2">
    <div class="div-block-37">
      <div class="w-layout-grid grid-9">
        <div class="div-block-39">
          <div class="div-block-34"><img src="images/logo-whitetext-png.png" loading="lazy" width="147" sizes="120px" srcset="images/logo-whitetext-png-p-500.png 500w, images/logo-whitetext-png-p-1080.png 1080w, images/logo-whitetext-png-p-1600.png 1600w, images/logo-whitetext-png-p-2000.png 2000w, images/logo-whitetext-png-p-2600.png 2600w, images/logo-whitetext-png-p-3200.png 3200w, images/logo-whitetext-png.png 4864w" alt=""></div>
        </div>
        <div class="div-block-36">
          <div class="div-block-38">
            <a href="index.php" aria-current="page" class="link-2 w--current">Home</a>
            <a href="contact.php" class="link-3">Contact</a>
            <a href="faq.php" class="link-4">FAQ</a>
            <a href="order.php" class="link-5">Order</a>
          </div>
        </div>
        <div class="div-block-36">
          <div class="socmed">
            <a href="https://facebook.com/kiminotakoyakiqc" class="link-6"></a>
            <a href="https://www.instagram.com/kiminotakoyaki/" class="link-7"></a>
          </div>
        </div>
      </div>
    </div>
  </div>
  </div>