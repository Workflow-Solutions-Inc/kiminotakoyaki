import { ButtonList } from '../options/buttons';
declare const initButtons: (buttons: ButtonList, dangerMode: boolean) => void;
export default initButtons;
