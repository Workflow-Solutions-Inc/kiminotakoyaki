import { SwalOptions } from '../options';
export declare const injectElIntoModal: (markup: string) => HTMLElement;
export declare const initModalContent: (opts: SwalOptions) => void;
declare const initModalOnce: () => void;
export default initModalOnce;
